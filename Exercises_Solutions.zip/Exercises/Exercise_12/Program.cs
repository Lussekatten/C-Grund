﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_12
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that output the multiplication table for 1 to 10 using nested for-loops. 
            //The format is not of great important but to make the code readably, 
            //add a tab after each number using the escape character \t.

            for (int i=1; i <= 10; i++)
            {
                Console.WriteLine("");
                for (int j = 1; j <= 10; j++)
                {
                    Console.Write("{0}\t", i*j);
                }
            }
            Console.Read();
        }
    }
}
