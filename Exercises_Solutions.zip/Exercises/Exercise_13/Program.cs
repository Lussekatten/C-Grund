﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_13
{
    class Program
    {
        static void Main(string[] args)
        {

            Random rnd = new Random();
            int correctAnswer = rnd.Next(0, 500);
            int numberOfAttempts = 0;

            Console.Write("Guess a number!");
            int userInput = int.Parse(Console.ReadLine());
            while (correctAnswer != userInput)
            {
                numberOfAttempts++;
                if (userInput < correctAnswer)
                {
                    Console.WriteLine("Go higher");
                    userInput = int.Parse(Console.ReadLine());
                }
                else if (userInput > correctAnswer)
                {
                    Console.WriteLine("Go lower");
                    userInput = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("Your guess is correct!");
            Console.WriteLine("You did it in {0} attempts", numberOfAttempts);

            Console.Read();
        }
    }
}
