﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_07
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter the radius: ");
            double theRadius = double.Parse(Console.ReadLine());
            double theArea = Math.PI * theRadius * theRadius;
            double theVolume = (4 * Math.PI * theRadius * theRadius * theRadius) / 3;

            Console.WriteLine("The area of a circle with radius of {0} equals: {1} m2", theRadius, theArea.ToString());
            Console.WriteLine("The volume of a sphere with same radius equals: {0} m3", theVolume.ToString());

            Console.Read();
        }
    }
}
