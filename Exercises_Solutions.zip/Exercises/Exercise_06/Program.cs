﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_06
{
    class Program
    {
        static void Main(string[] args)
        {
            //Here we go in the exciting realm of Mathemathics.
            //Assignment: Write the program code that lets the user input 2 integers from the console. 
            //Then let the program output:
            //1. the bigger number,
            //2. the smaller number, 
            //3. the difference ( - ), 
            //4. the sum (+), 
            //5. the product ( * ) and ratio ( / ) between the two numbers.

            Console.Write("Enter the first number: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Enter the second number: ");
            int num2 = int.Parse(Console.ReadLine());
            int difference = 0;
            int theSum = 0;
            int theProduct = 0;
            float theRatio = 0;

            //OBS! Use of data types such as float, double and decimal in conditional statements
            //can lead to unexpected results and should be avoided.
            if (num1 > num2)
            {
                Console.WriteLine("{0} is the bigger number", num1);
                Console.WriteLine("{0} is the smaller number", num2);
                difference = num1 - num2;
                Console.WriteLine("The difference (-) is: {0}", difference);
            }
            else if (num1 < num2)
            {
                Console.WriteLine("{0} is the bigger number",num2);
                Console.WriteLine("{0} is the smaller number", num1);
                difference = num2 - num1;
                Console.WriteLine("The difference (-) is: {0}", difference);
            }
            else
            {
                Console.WriteLine("The numbers are both equal to {0}", num2);
            }

            //Calcualte the sum
            theSum = num1 + num2;
            Console.WriteLine("The sum (+) is: {0}", theSum);

            //Calcualte the product
            theProduct = num1 * num2;
            Console.WriteLine("The product (*) is: {0}", theProduct);

            //Calcualte the ratio
            //For precise calculation, with decinal numbers we can use float variables
            //However, all the integer numbers involved must be cast to float type
            if (num1 !=0 && num2 !=0)
            {
                if (num2 > num1)
                {
                    theRatio = (float)num2 / (float)num1;
                    Console.WriteLine("The ratio (/) is: {0}", theRatio);
                }
                else if (num1 > num2)
                {
                    theRatio = (float)num1 / (float)num2;
                    Console.WriteLine("The ratio (/) is: {0}", theRatio);
                }
                else
                {
                    Console.WriteLine("The ratio (/) is 1.0");
                }
            }
            else
            {
                Console.WriteLine("Zero number operations might destroy my bits, you are so nasty!");
            }

            //Console.WriteLine("");

            Console.Read();
        }
    }
}
