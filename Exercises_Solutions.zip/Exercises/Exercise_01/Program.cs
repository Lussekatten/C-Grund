﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_01
{
    class Program
    {
        static void Main(string[] args)
        {

            string firstName = "Anders";
            string lastName = "Persson";
            Console.WriteLine("Hello {0} {1}! I’m glad to inform you that you are the test subject of my very first assignment",firstName,lastName);

            Console.Read();
        }
    }
}
