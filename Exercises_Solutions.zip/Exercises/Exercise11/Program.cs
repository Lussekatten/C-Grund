﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: ");
            int userInput = int.Parse(Console.ReadLine());

            for (int i = 1; i <= userInput; i++)
            {
                if (i % 2 == 0)
                {
                    //The number is even. Outpur is red colored
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("{0},",i);
                }
                else
                {
                    //Number is odd. Output color is green
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("{0},", i);
                }
            }

            Console.WriteLine();

            for (int i = userInput; i > 0; i--)
            {
                if (i % 2 == 0)
                {
                    //The number is even. Outpur is red colored
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("{0},", i);
                }
                else
                {
                    //Number is odd. Output color is green
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("{0},", i);
                }
            }
            Console.Read();
        }
    }
}
