﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_10
{
    class Program
    {
        static void Main(string[] args)
        {
            //int userInput = 1;

            DisplayMenu();
            ConsoleKeyInfo keyinfo;

            keyinfo = Console.ReadKey();
            while (keyinfo.Key != ConsoleKey.X)
            {
                if (keyinfo.Key == ConsoleKey.D1)
                {
                    while (keyinfo.Key != ConsoleKey.B)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Division();
                        keyinfo = Console.ReadKey();
                    }
                }

                if (keyinfo.Key == ConsoleKey.D2)
                {
                    while (keyinfo.Key != ConsoleKey.B)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.White;
                        LazyFox();
                        keyinfo = Console.ReadKey();
                    }
                }

                if (keyinfo.Key == ConsoleKey.D3)
                {
                    while (keyinfo.Key != ConsoleKey.B)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.White;
                        ChangeColor();

                        keyinfo = Console.ReadKey();
                    }
                }
            }
                        
            //userInput = int.Parse(Console.ReadLine());
            //switch (userInput)
            //{
            //    case 1:
            //        Division();
            //        break;
            //    case 2:
            //        LazyFox();
            //        break;
            //    case 3:
            //        ChangeColor();
            //        break;
            //    default:
            //        break;
            //}


            //Console.Read();
            

        }



        private static void LazyFox()
        {
            string originalText = "The quick fox Jumped Over the DOG";

            //Step 1: Simply replace a string with another
            string newString = originalText.Replace("quick", "brown");

            //Step 2: Find the position of a certain string ("Jumped") inside the original text using IndexOf()
            int position = newString.IndexOf("Jumped", 0);

            //Step 3: Remove a number of characters using Remove()
            newString = newString.Remove(position, 6);

            //Step 4: Insert another string ("jumped") in the same location
            newString = newString.Insert(position, "jumped");

            Console.WriteLine(newString);

        }

        private static void DisplayMenu()
        {
            Console.Clear();
            Console.WriteLine("1. Division");
            Console.WriteLine("2. Lazy fox");
            Console.WriteLine("3. Toggle color");
            Console.WriteLine("----------------");
            Console.WriteLine("X. Exit");
            Console.WriteLine("");
            Console.WriteLine("Your selection? ");
        }

        static void Division()
        {
            Console.Clear();
            Console.Write("Enter the first number: ");
            int num1 = int.Parse(Console.ReadLine());
            Console.Write("Enter the second number: ");
            int num2 = int.Parse(Console.ReadLine());
            
            while (num2 == 0)
            {
                //Console.Clear();
                Console.Write("This number can not be zero. Try again: ");
                num2 = int.Parse(Console.ReadLine());
            }

            float theRatio = (float)num1 / (float)num2;
            Console.WriteLine("The ratio (/) is: {0}", theRatio);
            
        }
        private static void ChangeColor()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("We just changed the color to blue");

         
        }
    }
}
