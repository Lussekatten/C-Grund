﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This program finds the first 3 perfect numbers");
            // A perfect number is a number where all its positive divisors sums up to the actual number

            int sumOfDivisors = 0;

            int num =3;
            int perfectNumbersFound = 0;

            while (perfectNumbersFound < 3)
            {
                sumOfDivisors = 0;
                num++;

                for (int i = 1; i < num; i++)
                {
                    if (num % i == 0)
                    {
                        //divisor found, add it to the sum
                        sumOfDivisors += i;
                    }
                }

                if (sumOfDivisors == num)
                {
                    Console.WriteLine("{0} is a perfect number", num);
                    perfectNumbersFound++;
                }
            }



            Console.Read();
        }
    }
}
