﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_26
{
    class Program
    {
        static void Main(string[] args)
        {
            //In this exercise, you are going to print out the folder path to some different locations on your computer. 
            //These can be found in the Enviroment-class. 
            //To print one of the common folders on your computer, you can use the Enviroment.GetFolderPath, 
            //passing it one of the values from the Enviroment.SpecialFolder enumeration. 
            //---------------------------------------------------------------------------
            //Print out the following locations on your computer:  Example: Enviroment.GetFolderPath(Enviroment.SpecialFolder.Desktop)  
            //• My documents  
            //• My Pictures  
            //• The folder containing information about cookies  
            //• Current Directory (found inside in the Enviroment class)
            List<string> lines = new List<string>();
            string fileName = "Example.txt";

            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            Console.WriteLine("Path - My documents: {0}",path);
            lines.Add("Path - My documents: " + path);

            path = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            Console.WriteLine("Path - My pictures: {0}", path);
            lines.Add("Path - My pictures: " + path);

            path = Environment.GetFolderPath(Environment.SpecialFolder.Cookies);
            Console.WriteLine("Path - Cookies: {0}", path);
            lines.Add("Path - My Cookies: " + path);

            path = Environment.CurrentDirectory;
            Console.WriteLine("Path - Curent directory: {0}", path);
            lines.Add("Path - My pictures: " + path);

            // Set a variable to the Documents path.
            path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            //string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);


            // Create a string array with the lines of text



            // Write the string array to a new file named "WriteLines.txt".
            //If the file already exists, the contents will be replaced
            //If an append was intended, open the StreamWriter with the "true" parameter
            //as in "...new StreamWriter(Path.Combine(docPath, "WriteLines.txt"), true))"
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(path, fileName)))
            {
                foreach (string line in lines)
                {
                    outputFile.WriteLine(line);
                }
            }

            Console.WriteLine("\nAll text saved in the file: {0} located on your Desktop", fileName);

            Console.Read();
        }
    }
}
