﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_25
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a separate function (from the exercise method) that asks the user to input a valid integer value. 
            //The function should keep executing until the user has inputted a valid integer value. 
            //Use a Try-catch combined with a while-loop. If the user inputs a none-valid number, 
            //display an error asking him/her to try again.

            Console.Write("Write a VALID integer number: ");
            string intString = Console.ReadLine();
            int mynumber = 0;
            int divisor = 0;
            float result = 0;


            while (intString != null)
            {
                try
                {
                    mynumber = int.Parse(intString);

                    //Do something
                    Console.WriteLine("The integer was accepted");
                    break;
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Integer number has wrong format!");
                    Console.WriteLine(e.Message);
                    Console.Write("Write a VALID integer number: ");
                    intString = Console.ReadLine();
                }
            }

            Console.Write("Write a VALID integer divisor: ");
            intString = Console.ReadLine();

            while (intString != null)
            {
                try
                {
                    divisor = int.Parse(intString);

                    //Do something
                    Console.WriteLine("The integer format was accepted..");
                    //but reject if zero
                    try
                    {
                        result = mynumber / divisor;
                        break;
                    }
                    catch (DivideByZeroException e)
                    {
                        Console.WriteLine("The divisor can not be zero!");
                        Console.WriteLine(e.Message);
                        Console.Write("Write a VALID DIVISOR integer number: ");
                        intString = Console.ReadLine();
                    }
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Integer number has wrong format!");
                    Console.WriteLine(e.Message);
                    Console.Write("Write a VALID integer number: ");
                    intString = Console.ReadLine();
                }
            }

            result = (float)mynumber / (float)divisor;
            Console.WriteLine("\n{0} / {1} = {2}", mynumber, divisor, result);


            Console.Read();
        }
    }
}
