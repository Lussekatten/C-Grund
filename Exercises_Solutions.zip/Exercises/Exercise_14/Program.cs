﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_14
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that keeps asking the user for input numbers, until he enters -1. 
            //Store the amount of numbers the user have entered and the sum of the numbers added together. 
            //When the user types -1, the program should display the sum and the average of the numbers.  
            //Write a program that keeps asking the user for input numbers, until he enters -1. 
            //Store the amount of numbers the user have entered and the sum of the numbers added together. 
            //When the user types -1, the program should display the sum and the average of the numbers

            Console.Write("Enter a number: ");
            string userInputString = Console.ReadLine();
            int userInputValue = int.Parse(userInputString);
            int howManyInputs = 0;
            int sum = 0;
            float average = 0;

            while (userInputString != "-1")
            {
                howManyInputs++;
                sum += userInputValue;
                average = (float)sum / (float)howManyInputs;

                Console.Write("Enter a number: ");
                userInputString = Console.ReadLine();
                userInputValue = int.Parse(userInputString);
            }

            Console.WriteLine("The sum of all the numbers you entered is: {0}",sum);
            Console.WriteLine("The average value is: {0}", average);

            Console.Read();
        }
    }
}
