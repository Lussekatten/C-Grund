﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_20
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create two arrays with arbitrary size and fill one with random numbers. 
            //Then copy over the numbers from the array with random numbers so that 
            //the even numbers are located in the rear (the right side) part of the array 
            //and the odd numbers are located in the front part (the left side).

            Random rnd = new Random();
            int arraySize = rnd.Next(14,26);

            int[] originalArray = new int[arraySize];
            int[] sortedArray = new int[arraySize];
            int sortedArrayIndex = 0;

            Console.WriteLine("Your array contains {0} elements", arraySize);

            //Give values to the original array
            for (int i = 0; i < originalArray.Length; i++)
            {
                originalArray[i] = rnd.Next(1,50);
                Console.Write("{0}, ",originalArray[i]);
            }

            Console.WriteLine();

            //Check for odd numbers first
            for (int i = 0; i < originalArray.Length; i++)
            {
                if (originalArray[i] % 2 != 0)
                {
                    sortedArray[sortedArrayIndex] = originalArray[i];
                    sortedArrayIndex++;
                }
            }

            //Check for even numbers now
            for (int i = 0; i < originalArray.Length; i++)
            {
                if (originalArray[i] % 2 == 0)
                {
                    sortedArray[sortedArrayIndex] = originalArray[i];
                    sortedArrayIndex++;
                }
            }

            //Print out the sorted array
            for (int i = 0; i < sortedArray.Length; i++)
            {
                Console.Write("{0}, ", sortedArray[i]);
            }

            Console.Read();
        }
    }
}
