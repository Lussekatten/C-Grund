﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_24
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> unshuffeledDeck = new List<string>();
            List<string> shuffeledDeck = new List<string>();
            InitializeCardDeck(unshuffeledDeck);
            string cardDrawn;

            //Verify that your deck is complete. It should contain 52 cards
            Console.WriteLine("Your unshuffeled deck contains: {0} cards",unshuffeledDeck.Count);
            ShowCardDeck(unshuffeledDeck);

            Console.WriteLine("\nShuffeling the cards now...\n");
            shuffeledDeck = ShuffleCards(unshuffeledDeck);
            ShowCardDeck(shuffeledDeck);

            Console.WriteLine();
            //Pick a card until the shuffeled deck is depleted
            while (shuffeledDeck.Count > 0)
            {
                cardDrawn = DrawCard(shuffeledDeck);
                Console.WriteLine("You just picked the {0} and the card was removed from the deck. You have only {1} cards sleft", cardDrawn, shuffeledDeck.Count);
            }

            Console.Read();
        }

        static void InitializeCardDeck(List<string> unDeck)
        {
            unDeck.Add("2 of clubs"); //klöver
            unDeck.Add("2 of diamonds"); //ruter
            unDeck.Add("2 of hearts"); //hjärter
            unDeck.Add("2 of spades"); //spader
            unDeck.Add("3 of clubs");
            unDeck.Add("3 of diamonds");
            unDeck.Add("3 of hearts");
            unDeck.Add("3 of spades");
            unDeck.Add("4 of clubs");
            unDeck.Add("4 of diamonds");
            unDeck.Add("4 of hearts");
            unDeck.Add("4 of spades");
            unDeck.Add("5 of clubs");
            unDeck.Add("5 of diamonds");
            unDeck.Add("5 of hearts");
            unDeck.Add("5 of spades");
            unDeck.Add("6 of clubs");
            unDeck.Add("6 of diamonds");
            unDeck.Add("6 of hearts");
            unDeck.Add("6 of spades");
            unDeck.Add("7 of clubs");
            unDeck.Add("7 of diamonds");
            unDeck.Add("7 of hearts");
            unDeck.Add("7 of spades");
            unDeck.Add("8 of clubs");
            unDeck.Add("8 of diamonds");
            unDeck.Add("8 of hearts");
            unDeck.Add("8 of spades");
            unDeck.Add("9 of clubs");
            unDeck.Add("9 of diamonds");
            unDeck.Add("9 of hearts");
            unDeck.Add("9 of spades");
            unDeck.Add("10 of clubs");
            unDeck.Add("10 of diamonds");
            unDeck.Add("10 of hearts");
            unDeck.Add("10 of spades");
            unDeck.Add("Jack of clubs");
            unDeck.Add("Jack of diamonds");
            unDeck.Add("Jack of hearts");
            unDeck.Add("Jack of spades");
            unDeck.Add("Queen of clubs");
            unDeck.Add("Queen of diamonds");
            unDeck.Add("Queen of hearts");
            unDeck.Add("Queen of spades");
            unDeck.Add("King of clubs");
            unDeck.Add("King of diamonds");
            unDeck.Add("King of hearts");
            unDeck.Add("King of spades");
            unDeck.Add("Ace of clubs");
            unDeck.Add("Ace of diamonds");
            unDeck.Add("Ace of hearts");
            unDeck.Add("Ace of spades");
        }

        static string DrawCard(List<string> deck)
        {  // code to draw a card here
            Random rnd = new Random();
            int index = rnd.Next(0, deck.Count - 1);
            string cardDrawn = deck[index];
            deck.Remove(deck[index]);
            return cardDrawn;
        }

        static List<string> ShuffleCards(List<string> deck)
        {  // code to shuffle the deck here
            int indexValue;
            int indexesCreated = 0;

            Random rnd = new Random();
            List<int> cardIndexes = new List<int>();
            List<string> shuffeledDeck = new List<string>();

            while (indexesCreated < 52)
            {

                //create unique indexes for all card slots (1-52)
                indexValue = rnd.Next(0, 52);
                if (!cardIndexes.Contains(indexValue))
                {
                    cardIndexes.Add(indexValue);
                    indexesCreated++;
                }
            }

            for (int i = 0; i < deck.Count; i++)
            {
                indexValue = cardIndexes[i];
                shuffeledDeck.Add(deck[indexValue]);
                //shuffeledDeck[i] = deck[cardIndexes[i]];
            }

            return shuffeledDeck;
        }

        static void ShowCardDeck(List<string> cardDeck)
        {
            foreach (var item in cardDeck)
            {
                Console.WriteLine("{0}",item);
            }
        }

    }
}
