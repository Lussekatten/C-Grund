﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_02
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime today = DateTime.Now;
            DateTime yesterday = today.AddDays(-1);
            DateTime tomorrow = today.AddDays(1);

            Console.WriteLine("Today's date is {0} ", today.Date.ToString());
            Console.WriteLine("Yesterday's date is {0} ", yesterday.Date.ToString());
            Console.WriteLine("Tomorrow's date is {0} ", tomorrow.Date.ToString());

            //If you need to use/show just the date part of the DateTime, use ToShortDateString() method of the DateTime class
            //as shown below
            Console.WriteLine("Today's date is {0} ", today.Date.ToShortDateString()); 

            Console.Read();
        }
    }
}
