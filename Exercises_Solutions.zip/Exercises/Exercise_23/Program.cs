﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_23
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a program that generates 7 unique numbers into an array.The numbers should be between 1 and 40.
            //Each of the numbers may only appear once in the array!
            //The numbers should be generated using the Random-class, and should be different each time you run the program.
            //Tip: Lists are more appropriate for this task

            List<int> myList = new List<int>();
            Random rnd = new Random();
            int checkMe;

            while (myList.Count() < 7)
            {
                checkMe = rnd.Next(1, 10);
                if (!myList.Contains(checkMe))
                {
                    myList.Add(checkMe);
                }
            }

            Console.WriteLine("List of unique numbers");
            foreach (var item in myList)
            {
                Console.Write("{0}, ", item);
            }

            Console.Read();
        }
    }
}
