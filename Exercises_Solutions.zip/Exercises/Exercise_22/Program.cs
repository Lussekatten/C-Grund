﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_22
{
    class Program
    {
        static void Main(string[] args)
        {
            //The company See sharp AB have discovered that the users on their forums use a very harsh language when interacting with each other. 
            //So now they have asked you to write a swear word filter to censor these occurring words. 
            //Before implementing this filter on their website, they want a demonstration in form of a console program.  
            //The program should ask the user for a textual input. Then it should check for all occurrences of swear words. 
            //Store the swear words in an array and check the textual input against the array and use string manipulation 
            //to replace all swear words with something more appropriate.

            string[] censuredWords = new string[] { "fuck", "hell", "shit", "asshole", "idiot" };
            string repalcement = " beep...";
            int position = 0;

            Console.WriteLine("Enter some text and use foul language");
            string userInput = Console.ReadLine();
            for (int i = 0; i < censuredWords.Length; i++)
            {
                position = userInput.IndexOf(censuredWords[i]);
                if (position >= 0)
                {
                    userInput = userInput.Replace(censuredWords[i], repalcement);
                }
            }

            Console.WriteLine("\nUser friendly version:");
            Console.WriteLine(userInput);
            Console.Read();
        }
    }
}
