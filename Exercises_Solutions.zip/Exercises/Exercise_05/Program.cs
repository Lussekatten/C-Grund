﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_05
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Arrays are very common in programming, they look something like: [1,2,3,4,5]";

            //Substring is a handy method to select a specific portion from a larger string and store it away
            //We are using IndexOf so we can find the location of "[" in the "str" variable
            string newString = str.Substring(str.IndexOf("["),11);
            //The newString contains now [1,2,3,4,5]

            newString = newString.Replace("2,3,", "");
            //The newString contains now [1,4,5]

            //As a final step, find the position of "]" and insert the string ",6,7,8,9,10" at that location
            newString = newString.Insert(newString.IndexOf("]"), ",6,7,8,9,10");

            Console.WriteLine(newString);

            Console.ReadLine();
        }
    }
}
