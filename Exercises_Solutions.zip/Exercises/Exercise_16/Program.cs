﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_16
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that asks the user for a number. 
            //Use this number to output the Fibonacci series up until that number. 
            //Entering 10 should then output: 0, 1, 1, 2, 3, 5, 8, 13, 21 and 34
            int previous = 0;
            int next = 0;
            int current = 0;
            int max;

            Console.Write("Enter a number: ");
            max = int.Parse(Console.ReadLine());
            for (int i = 0; i <= max; i++)
            {
                next = GetNextFibonacci(previous, current);
                previous = current;
                current = next;
            }

            Console.Read();
        }

        static int GetNextFibonacci(int prev=0, int cur=0)
        {
            int next = 0;
            if (prev==0 && cur ==0)
            {
                Console.Write("0, 1, ");
                return 1;
            }
            else
            {
                next = prev + cur;
                Console.Write("{0}, ",next);
                return prev + cur;
            }
        }
    }
}
