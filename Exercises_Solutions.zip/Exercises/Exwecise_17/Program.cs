﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_17
{
    class Program
    {
        static void Main(string[] args)
        {
            //Let the user input a string, then check if the string is a palindrome sentence. 
            //A palindrome is a word or sentence that reads the same in both directions. 
            //Example of palindrome sentences are: Loops at a spool, wet stew and level. 
            //However, the spaces might look different depending on which direction you read it, 
            //so these should be excluded in your calculations, and a tip is to use some string manipulation to remove them.
            string afterTransformation = "";

            Console.WriteLine("Enter a String to check for Palindrome");

            string input = Console.ReadLine();

            int iLength = input.Length;

            if (iLength == 0)
            {
                Console.WriteLine("You did not enter the string");

            }

            else
            {

                for (int j = iLength - 1; j >= 0; j--)
                {
                    afterTransformation = afterTransformation + input[j];
                }

                if (afterTransformation == input)
                {
                    Console.WriteLine(input + " is palindrome");
                }
                else
                {
                    Console.WriteLine(input + " is not a palindrome");
                }
            }
            Console.Read();
        }
    }
}
