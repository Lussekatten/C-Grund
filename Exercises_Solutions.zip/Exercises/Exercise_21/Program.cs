﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_21
{
    class Program
    {
        static void Main(string[] args)
        {
            //Let the user input a string with numbers comma separated like “1,2,34,83,19,45”. 
            //Create the code to separate the numbers in the string into an array and find the min, max and average value. 
            //Print these out to the screen. Tip: use the Split-function on the String-object. 
            //Keep in mind that the Split-method returns an array of Strings, so you have to convert each value to an integer 
            //before you can do the calculations.

            Console.WriteLine("Enter your numbers, comma separated");
            string userInput = Console.ReadLine();
            string[] splitedInput = userInput.Split(',');
            int sumOfAllNumers = 0;

            //Check to see that the numbers were stored properly
            for (int i = 0; i < splitedInput.Length; i++)
            {
                sumOfAllNumers += int.Parse(splitedInput[i]);
                Console.Write("{0} + ", splitedInput[i]);
            }

            Console.WriteLine("= {0}", sumOfAllNumers);

            Console.Read();
        }
    }
}
