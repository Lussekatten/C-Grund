﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_04
{
    class Program
    {
        static void Main(string[] args)
        {
            string originalText = "The quick fox Jumped Over the DOG";

            //Should become, after string manipulations  “The brown fox jumped over the lazy dog”
            //Allowed methods are (IndexOf, Remove, Replace, Insert)
            //Hint: Try using as many methods as you can, so you can learn how they work

            //Step 1: Simply replace a string with another
            string newString = originalText.Replace("quick","brown");

            //Step 2: Find the position of a certain string ("Jumped") inside the original text using IndexOf()
            int position = newString.IndexOf("Jumped", 0);

            //Step 3: Remove a number of characters using Remove()
            newString = newString.Remove(position, 6);

            //Step 4: Insert another string ("jumped") in the same location
            newString = newString.Insert(position, "jumped");

            //If you understand this methods, congratulations, mission accomplished

            Console.WriteLine(newString);

            Console.Read();
        }
    }
}
