﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your first name please: ");
            string firstName = Console.ReadLine();
            Console.Write("Enter your last name please: ");
            string lastName = Console.ReadLine();
            Console.WriteLine("Hello {0} {1}!", firstName, lastName);

            Console.Read();
        }
    }
}
