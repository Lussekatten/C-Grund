﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_19
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a program that outputs a price that the customer (user) needs to pay. 
            //This should be an integer value. Then let the user input the sum he hands the cashier. 
            //Let your program then calculate the change that the customer should get back in different coin unit. 
            //For example, if the user hands the cashier 500 kr. and the price is 376 kr., the change will be 124. 
            //This can be divided up into 100x1 kr. + 20x1 kr. + 4x1 kr. The goal here is to get as few coins as possible.  

            //Tip: Use an array to store the different coin units, like 100, 50, 20 etc.
            //When you have calculated the change, go through the coin units from larges to smallest and calculate how many 
            //of each type the customer should get back. Here is a perfect scenario when integer division and modulus is viable to use.
            //A bit tricky to be honest

            Console.Write("Enter the price of the product: ");
            int prodPrice = int.Parse(Console.ReadLine());
            Console.Write("You pay: ");
            int yourPayment = int.Parse(Console.ReadLine());
            int difference = yourPayment - prodPrice;
            //Once you find a coin type to use, you need to calculate how much money you have left
            //that needs to be distributed to other (lower) coin types
            int restToCheck = difference;
            //noOfCoins will store the total number of coins used, no matter what type
            int totalNoOfCoins = 0;

            //noOfCoins will store the number of coins used for a particular coin type
            int noOfCoins = 0;

            //int divisionResult = 0;
            int[] coinTypes = new int[] { 100, 80, 50, 20, 10, 5, 1 };

            Console.WriteLine("You should receive: {0}\n",difference);

            //This loop will check what coin types are appropriate to use, starting from the biggest value coin type
            //and moving towards the lowest coin type
            for (int i = 0; i < coinTypes.Length; i++)
            {
                noOfCoins = 0;
                noOfCoins = restToCheck / coinTypes[i];

                //check to see if divisionResult generated a number bigger than 1. If it did, we can use tht type of coin
                if (noOfCoins >= 1)
                {
                    totalNoOfCoins += noOfCoins;
                    restToCheck = restToCheck - noOfCoins * coinTypes[i];
                    Console.WriteLine("We used {0} coins of type {1}", noOfCoins, coinTypes[i]);
                }
            }

            Console.WriteLine("Total number of coins used: {0}", totalNoOfCoins);

            Console.Read();
        }
    }
}
