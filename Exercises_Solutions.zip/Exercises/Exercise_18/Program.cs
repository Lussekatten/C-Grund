﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_18
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] intArr = new int[10];
            double[] dblArr = new double[10];

            Random rnd = new Random();
            for (int i = 0; i < intArr.Length; i++)
            {
                intArr[i] = rnd.Next(1, 50);
                Console.Write("{0}, ",intArr[i]);
            }

            Console.WriteLine("");

            for (int i = 0; i < dblArr.Length; i++)
            {
                dblArr[i] = 1 / (double)intArr[i];
                //Format the output of doubles to 2 decimal places
                Console.Write("{0:0.00}, ", dblArr[i]);
            }
            Console.Read();
        }
    }
}
