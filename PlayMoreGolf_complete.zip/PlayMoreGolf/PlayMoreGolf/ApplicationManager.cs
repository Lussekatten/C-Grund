﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayMoreGolf
{
    class ApplicationManager
    {
        public ApplicationManager()
        {
            MaxStrikesAllowed = 10;
            TotalDistanceTravelled = 0;
            CourseLength = rnd.Next(580, 701);
            Swings = new List<Swing>();
        }

        internal int _scale = 20;
        private double _GRAVITY = 9.8;
        public int CourseLength { get; set; }
        public double TotalDistanceTravelled { get; set; }
        public int MaxStrikesAllowed { get; set; }

        public double DistanceToCup { get; set; }
        public int StrikesSoFar { get; set; }

        public List<Swing> Swings { get; set; }

        private Random rnd = new Random(DateTime.Now.Millisecond);

        private Swing  _lastStrike = null;

        public void SimulateStrike(int angle, int velocity)
        {
            //Caps the velocity to 58 m/s sure if it is a realistic number but anyway
            if (velocity > 58)
            {
                velocity = 58;
            }
            double angleInRadians = (Math.PI / 180) * angle;
            double distance = Math.Pow(velocity, 2) / _GRAVITY * Math.Sin(2 * angleInRadians);

            TotalDistanceTravelled += distance;
            DistanceToCup = (double)CourseLength - TotalDistanceTravelled;

            //Recalculate the TotalDistanceTravelled in case you hit the ball too hard
            if (DistanceToCup < 0)
            {
                DistanceToCup = Math.Abs(DistanceToCup);
                TotalDistanceTravelled = (double)CourseLength - DistanceToCup;
            }

            //Create the strike object to put in the list of strikes
            Swing strike = new Swing(angle, velocity, distance);
            //strike.Angle = angle;
            //strike.Velocity = velocity;
            //strike.DistanceTravelled = distance;

            //Save the information about the last strike here to display to the user (if needed)
            _lastStrike = strike;

            //Add it to the list
            Swings.Add(strike);
            StrikesSoFar++;
        }
        public void DisplayStrikeStats()
        {
            Console.WriteLine("--------------------------------------------------------------");
            Console.WriteLine("-------------------------- Results ----------------------------");
            Console.WriteLine("---------------------------------------------------------------");
            foreach (var item in Swings)
            {
                Console.WriteLine("Strike {0}", Swings.IndexOf(item) + 1);
                Console.WriteLine("Angle {0}", item.Angle);
                Console.WriteLine("Velocity {0}", item.Velocity);
                Console.WriteLine("Distance {0:0.00} m", item.DistanceTravelled);
                Console.WriteLine("---------------------------------------");
            }
        }

        public void DisplayVisuals(int scale, double distanceTravelled)
        {
            //One letter coresponds to 30 meters
            //Display distance so far
            int noOfSymbols = (int)(distanceTravelled / scale);
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            for (int i = 0; i < noOfSymbols; i++)
            {
                Console.Write("O");
            }
            //Display remaining distance
            noOfSymbols = (int)(DistanceToCup / scale);
            if (noOfSymbols < 1)
            {
                noOfSymbols = 1;
            }
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            for (int i = 0; i < noOfSymbols; i++)
            {
                Console.Write("o");
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
        }
        public void DisplayStatsToPlayer()
        {
            Console.WriteLine("---------------------------------------------------");
            DisplayVisuals(_scale, TotalDistanceTravelled);
            Console.Write("Strike {0}. ", Swings.Count);
            Console.WriteLine("You have {0} strikes left", MaxStrikesAllowed - Swings.Count);
            Console.WriteLine("Your last strike measured {0:0.00} meters", _lastStrike.DistanceTravelled);
            Console.WriteLine("Distance to taget is now {0:0.00}", DistanceToCup);
        }

        public void DisplayStartInfo()
        {
            //Some info to the user about the purpose of the game
            Console.WriteLine("You are a golf player trying to get as close to the flag/cup as possible.");
            Console.WriteLine("You can modify the angle and velocity for every strike.");
            Console.WriteLine("The length of this course is {0} meters", CourseLength);
            Console.WriteLine("You have a maximum of 10 attempts. Good luck!");
            Console.WriteLine("---------------------------------------------------------");
        }
    }
}
