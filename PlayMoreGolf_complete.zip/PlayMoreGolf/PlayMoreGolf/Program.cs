﻿using System;

namespace PlayMoreGolf
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationManager am = new ApplicationManager();

            int angle;
            int velocity;
            bool success = false;

            am.DisplayStartInfo();

            while (am.StrikesSoFar < am.MaxStrikesAllowed)
            {
                Console.Write("Enter angle: ");
                angle = int.Parse(Console.ReadLine());
                Console.Write("Enter velocity: ");
                velocity = int.Parse(Console.ReadLine());
                am.SimulateStrike(angle, velocity);
                am.DisplayStatsToPlayer();

                if ((int)am.DistanceToCup == 0)
                {
                    success = true;
                    break;
                }
            }

            am.DisplayStrikeStats();
            if (success)
            {
                Console.WriteLine("Well done, you are the best!");
            }
            else
            {
                Console.WriteLine("Better luck next time!");
            }
            //Console.WriteLine("Hello World!");

            Console.Read();
        }
    }
}
