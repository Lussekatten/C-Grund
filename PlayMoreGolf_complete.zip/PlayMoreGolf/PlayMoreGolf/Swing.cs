﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayMoreGolf
{
    class Swing
    {
        public Swing(int ang, int vel, double dist)
        {
            Angle = ang;
            Velocity = vel;
            DistanceTravelled = dist;
        }
        public int Angle { get; set; }
        public int Velocity { get; set; }
        public double DistanceTravelled { get; set; }
    }
}
