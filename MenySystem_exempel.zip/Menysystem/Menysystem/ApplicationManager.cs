﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menysystem
{
    class ApplicationManager
    {
        public ApplicationManager()
        {
            
        }
        public int Balance { get; set; }
        public void DisplayMainMenu()
        {
            Console.Clear();
            Console.WriteLine("1. Main menu option 1");
            Console.WriteLine("2. Main menu option 2");
            Console.WriteLine("Q. Quit");
            Console.WriteLine("-----------------------");
            Console.WriteLine("Current balance: {0}", Balance);
        }
        private void DisplaySubmenu()
        {
            Console.Clear();
            Console.WriteLine("1. Submenu option 1");
            Console.WriteLine("2. Submenu option 2");
            Console.WriteLine("3. Submenu option 3");
            Console.WriteLine("4. Submenu option 4");
            Console.WriteLine("Q. Quit");

        }

        public void MainMenuOptionOne()
        {
            DisplaySubmenu();
            ConsoleKeyInfo keyinfo;
            keyinfo = Console.ReadKey();


            while (keyinfo.Key != ConsoleKey.Q)
            {
                switch (keyinfo.Key)
                {
                    case ConsoleKey.D1:
                        DoSomething(1);
                        break;
                    case ConsoleKey.D2:
                        DoSomething(5);
                        break;
                    case ConsoleKey.D3:
                        DoSomething(10);
                        break;
                    case ConsoleKey.D4:
                        DoSomething(20);
                        break;
                    default:
                        break;
                }
                DisplaySubmenu();
                keyinfo = Console.ReadKey();
            }
        }
        public void DoSomething(int amount)
        {
            Balance += amount;
        }
        
    }
}
