﻿using System;

namespace Menysystem
{
    class Program
    {
        static void Main(string[] args)
        {
            //Start by creating the ApplicationManager object so you can access all those
            //useful methods we put inside
            ApplicationManager am = new ApplicationManager();


            //Show the main menu and read the key the user is pressing
            //When Console.ReadKey() is used, you don't need to press Enter after each key press
            //Just press the number key that represents the choice (1-9 or Q)
            am.DisplayMainMenu();
            ConsoleKeyInfo keyinfo;
            keyinfo = Console.ReadKey();

            //The while loop is checking if you want to quit or not
            //If you don't want to quit, then the code indide the while loop gets executed
            while (keyinfo.Key != ConsoleKey.Q)
            {
                //The switch-case checks what number you pressed
                //ConsoleKey.D1 means You pressed the 1-key, ConsoleKey.D2 means You pressed the 2-key, etc.
                switch (keyinfo.Key)
                {
                    //If the 1-key is pressed execute the code inside the case
                    case ConsoleKey.D1:
                        am.MainMenuOptionOne();
                        break;
                    //If the 2-key is pressed execute the code inside the case
                    case ConsoleKey.D2:
                        //Do something else here
                        break;

                    default:
                        break;
                }
                //Show the menu again
                am.DisplayMainMenu();
                //And read the key the user is pressing
                keyinfo = Console.ReadKey();
            }
        }
    }
}
