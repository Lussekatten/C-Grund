﻿using System;

namespace PassingValues
{
    class Program
    {
        static void Main(string[] args)
        {
            int test = 5;
            string myString = "start";
             ByValue(test);
            ByReference(myString);
            Console.WriteLine("Hello World!");
        }
        static void ByValue(int myInput)
        {
            myInput++;
            
            Console.WriteLine("Value from method: {0}", myInput);
        }
        static void ByReference(string myInput)
        {
            myInput = myInput + " extrText";

            Console.WriteLine("Value from method: {0}", myInput);
        }
    }
}
