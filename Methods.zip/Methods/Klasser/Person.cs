﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Klasser
{
    class Person
    {
        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            MiddleName = "";
            Age = 20;
        }

        public Person(string firstName, string middleName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            MiddleName = middleName;
            Age = 20;
        }
        public string FirstName { get; set; } // The property FirstName
        public string MiddleName { get; set; } // The property FirstName
        public string LastName { get; set; } // The property LastName

        //public int Age { get; set; }
        private int _age;
        public int Age 
        { 
            get { 
                return _age; 
            } 
            set { 
                _age = value; 
            } 
        }

        public void Ageing()
        {
            Age++;
        }
        //public string FirstName { get; set; }
    }
}
