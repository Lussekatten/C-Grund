﻿using System;

namespace Klasser
{
    class Program
    {
        static void Main(string[] args)
        {

            Person myPers = new Person("Kalle","Andersson");
            Person myPers2 = new Person("Pelle", "C.", "Nyqvist");
            //int age = myPers.Age;
            myPers2.Ageing();
            string firstName = myPers.FirstName;
            ByReference(myPers);
            Console.WriteLine("First name: {0} Middle name: {1} Last name: {2} Age: {3}", myPers.FirstName, myPers.MiddleName, myPers.LastName, myPers2.Age);
            Console.WriteLine("First name: {0} Middle name: {1} Last name: {2} Age: {3}", myPers2.FirstName, myPers2.MiddleName, myPers2.LastName, myPers2.Age);
        }

        static void ByReference(Person myInput)
        {
            myInput.FirstName = "New name";

            Console.WriteLine("Value from method: {0}", myInput.FirstName);
        }
    }
}
