﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_08
{
    class Program
    {
        static void Main(string[] args)
        {
            // Svar:
            // For-loopen används bäst när man vet på förhand hur många gånger du vill köra samma kodavsnitt.
            // Foreach-loopen används med fördel när du har att göra med collections av olika slag (listor eller arrays), eftersom den går igenom HELA din collection automatiskt
            // While-loopen använder man oftast när stopp-villkoret för loopen inte hamnar i de ovannämnda kategorierna. Om man vill göra en oändlig loop, går det också bra med "while".
            Console.Read();
        }
    }
}
