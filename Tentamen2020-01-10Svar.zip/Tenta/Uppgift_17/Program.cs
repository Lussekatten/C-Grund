﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first number: ");
            int no1=int.Parse(Console.ReadLine());
            Console.Write("Enter the second number: ");
            int no2 = int.Parse(Console.ReadLine());
            Swap(ref no1, ref no2);
            Console.WriteLine("First parameter: {0}",no1);
            Console.WriteLine("Second parameter: {0}", no2);

            Console.Read();
        }

        //Svar
        static void Swap(ref int var1, ref int var2)
        {
            int temp;
            temp = var1;
            var1 = var2;
            var2 = temp;
        }
    }
}
