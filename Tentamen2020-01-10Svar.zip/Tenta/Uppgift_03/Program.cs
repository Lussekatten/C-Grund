﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_03
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vad skrivs ut i konsolen ?

            string some = "12345";
            string more = "67890";
            string text = some + more;

            string partOfText = text.Substring(0, 1) + text.Substring(9, 1);
            Console.WriteLine(partOfText); //10
            Console.Read();
        }
    }
}
