﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_06
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i > 10; i++)
            {
                Console.WriteLine("The output is {0}", i);
            }

            Console.Read();
        }
    }
}
