﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_13
{
    class Program
    {
        static void Main(string[] args)
        {
            minFilmlista = new List<string>();
            //Svar: minFilmlista saknar datatyp. List<string> ska man skriva innan variabelnamnet minFilmlista
        }
    }
}
