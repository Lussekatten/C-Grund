﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_01
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vad visar konsolen när programmet körs?

            int a = 1;
            int b = 5;

            int c = a + b;
            int d = a / b;

            Console.WriteLine(c); // 6
            Console.WriteLine(d); // 0 because d is declared as an integer and the decimal part gets truncated (deleted)

            Console.ReadLine();
        }
    }
}
