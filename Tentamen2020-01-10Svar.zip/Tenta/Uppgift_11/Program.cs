﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] intArr = new int[] { 100, 200, 300, 400, 500 };

            intArr[0] = 30;
            intArr[4] = 20;

            int sum = 0;
            for (int i = 0; i < intArr.Length; i++)
            {
                sum += intArr[i];
            }
            Console.WriteLine("Summa: {0}", sum);
            Console.Read();
        }
    }
}
