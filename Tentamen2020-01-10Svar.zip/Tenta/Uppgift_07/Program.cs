﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_07
{
    class Program
    {
        static void Main(string[] args)
        {
            // Modulo operatorn passar jättebra i sammanhang där man måste utföra en viss operation med ett bestämt intervall.
            //Om det önskade intervallet är t.ex. varannan gång kan man t.ex. använda sig av modulo 2. 
            //Önskar man utföra något var tredje gång, använder man modulo 3, osv..

            //Modulo exempel: Skapa en for-loop och skriv på skärmen något varannan gång.
            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine("Iterator value is: {0}",i);
                }
            }
            Console.Read();
        }
    }
}
