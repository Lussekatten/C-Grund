﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_04
{
    class Program
    {
        static void Main(string[] args)
        {
            string test = "We meet once again";

            //4a. Svar
            // Ni behövde inte svara med exempel. Exemplen finns med här på metoder och properties så att ni ser hur de kan användas
            //Replace - Metod som byter ut text med annan text inuti en textsträng
            test = test.Replace("meet once", "don't meet");
            //int a = test.GetHashCode();
            
            
            //Remove - Metod som tar bort del av text från textsträngen
            //Length - Property som returnerar längden på textsträngen
            test = test.Remove(test.Length - 5, 5);
            Console.WriteLine(test);  //We don't meet
            //Console.WriteLine(a);  //The hash code

            //4b. Svar
            //Datatypen "int" lagrar heltal. Dessa förekommer bland annat i for loopar eller räknare av olika slag
            //Datatypen "float" lagrar decimaltal. Dessa förekommer bland annat i beräkningar som kräver noggranhet (2-3 decimalers noggranhet är inte ovanligt i vissa applikationer)
            //Datatypen "string" lagrar text. Textbearbetning förekommer nästa alltid inom programmering, t.ex. när man snyggar till data som kommer från en databas elelr textfil, eller formaterar om datumet
            //Datatypen "bool" lagrar vädena sant elelr falskt. Datatypen används oftast i villkorssatser av olka slag, eller innuti while loopar.
            //Datatypen "array" lagrar flera värden av samma slag. Man kan använda arrays för att t.ex lagra flera objekt på "samma ställe" och nå dessa via samma variabelnamn, fast med olika index

            Console.Read();
        }
    }
}
