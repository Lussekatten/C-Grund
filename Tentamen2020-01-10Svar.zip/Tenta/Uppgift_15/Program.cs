﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_15
{
    class Program
    {
        static void Main(string[] args)
        {
            //Svar:
            //a. Metod_C
            //b. Metod_D
            //c. Metod_B och Metod_F
            //d Metod_A, Metod_C och Metod_E
        }
    }
}
