﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_12
{
    class Program
    {
        static void Main(string[] args)
        {
            //Teori
            //1. Constuctors - Tar hand om initiering av vissa saker inne i klassen vare sig det gäller properties eller andra collections som ska initialiseras/skapas eller kod som behöver köras med olika metodanrop
            //2. Properties - Data som klassen exponerar utåt för access.
            //3. Fields - Interna variabler av olika datatyper som inte behöver "synas utåt". Koden inom klassens metoder kan dock använda sig av dessa variabler på olika sätt
            //4. Methods - Fungerar som funktioner som kan anropas vid behov antingen utifrån eller inifrån, från andra metoder inom klassen (eller konstruktorn). 
        }
    }
}
