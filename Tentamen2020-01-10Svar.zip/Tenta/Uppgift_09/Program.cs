﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_09
{
    class Program
    {
        static void Main(string[] args)
        {
            int j = 0;
            while (j < 10)
            {
                Console.WriteLine("Villkoret är sant för j är nu " + j);
                if (j < 9)
                {
                    j++;
                }
            }
            //This point will never be reached since the last incrementing of j is from 8 to 9, inside the if statement. 
            //After that, we are stuck inside the while loop, printing indefinitely to the console.
            Console.WriteLine("The end");
            Console.Read();
        }
    }
}
