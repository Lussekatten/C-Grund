﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_18
{
    class Program
    {
        static void Main(string[] args)
        {

            int a = 3;
            //if (a==1)
            //{
            //    Console.WriteLine("This is good");
            //}
            //else if (a==2)
            //{
            //    Console.WriteLine("This is better");
            //}
            //else if (a==3)
            //{
            //    Console.WriteLine("This is Nitro");
            //}

            switch (a)
            {
                case 1:
                    Console.WriteLine("This is good");
                    break;
                case 2:
                    Console.WriteLine("This is better");
                    break;
                case 3:
                    Console.WriteLine("This is Nitro");
                    break;
                default:
                    break;
            }

            Console.Read();
        }
    }
}
