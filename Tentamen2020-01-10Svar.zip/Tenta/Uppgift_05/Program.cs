﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_05
{
    class Program
    {
        static void Main(string[] args)
        {
            // Logical OR
            int a = 6;
            int b = 5;
            //Om variabeln a är mindre än 2 eller b är större eller lika med 5, skriv ut texten ”OR test passed” annars skriv ut texten ”OR test failed”. 
            if (a<2 || b>=5)
            {
                Console.WriteLine("OR test passed"); //Correct
            }
            else
            {
                Console.WriteLine("OR test failed");
            }

            //Om variabeln a är större än 2 och b är mindre än 6, skriv ut texten ”AND test passed” annars skriv ut texten ”AND test failed”. 
            if (a>2 && b<6)
            {
                Console.WriteLine("AND test passed"); //Correct
            }
            else
            {
                Console.WriteLine("AND test failed");
            }

            Console.Read(); 
        }
    }
}
