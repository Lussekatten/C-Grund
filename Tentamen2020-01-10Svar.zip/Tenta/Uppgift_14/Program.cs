﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_14
{
    class Program
    {
        static void Main(string[] args)
        {
            double fullPrice = 95;
            double discount = 10;
            
            Console.WriteLine("Full price: {0}",fullPrice);
            Console.WriteLine("Discount: {0}", discount);
            Console.WriteLine("Discounted price: {0}", GetDiscountedPrice(fullPrice, discount));
            Console.Read();
        }

        //Svar:
        static double GetDiscountedPrice(double fullPrice, double discount)
        {
            return fullPrice - (fullPrice * discount / 100);
        }

        //static double GetDiscountedPrice(double fullPrice, double rabbat)
        //{
        //    return fullPrice - (fullPrice * discount / 100);
        //}
    }
}
