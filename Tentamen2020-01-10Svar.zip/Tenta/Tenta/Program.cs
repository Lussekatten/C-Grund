﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tenta
{
    class Program
    {
        static void Main(string[] args)
        {
            //int j = 0;
            //while (j < 10)

            //{
            //    Console.WriteLine("Villkoret är sant för j är nu {0}", j++);

            //}


            //7. Här finns syntaxfel – vilka ? Svar: break-satser saknas;
            //int tal = 5;
            //switch (tal)
            //{
            //    case 1:
            //        Console.WriteLine("Du angav 1 ");
            //        break;
            //    case 3:
            //        Console.WriteLine("Du angav 3");
            //        break;
            //    case 4:
            //    case 5:
            //        Console.WriteLine("Du angav 4 eller 5 ");
            //        break;
            //    default:
            //        Console.WriteLine("Du har inte angivit ett godkänt tal ");
            //        break;
            //}

            //10. Vad skrivs ut från följande kod?
            //Svar: 0,1,2,3,7,8
            int m = 0;
            while (m < 10)
            {
                if (m > 3 && m < 7)
                {
                    m++;
                    continue;
                }
                if (m > 8)
                {
                    break;
                }
                Console.WriteLine(m);
                m++;
            }

            Console.Read();
        }
    }
}
