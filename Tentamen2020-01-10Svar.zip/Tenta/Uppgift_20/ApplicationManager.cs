﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_20
{
    class ApplicationManager
    {
        public ApplicationManager()
        {
            CreateHouses();
        }

        private List<House> _houses = new List<House>();

        /// <summary>
        /// Metod som skapar 2 hus med fördefinierade värden och lägger dessa i listan över hus
        /// </summary>
        public void CreateHouses()
        {
            House h = new House(1, "Eriksberg", 12000, "Sergels torg 14, 428 34 Eriksberg");
            h.CreateRoom("Living room", "oak", 24);
            h.CreateRoom("Kitchen", "marble", 16);
            h.CreateRoom("Bedroom 1", "Plastic", 14);
            h.CalculateHouseArea();
            _houses.Add(h);
            h = new House(2, "Angered", 6500, "Hjällbovallen 12, 424 44 Angered");
            h.CreateRoom("Living room", "plastic", 18);
            h.CreateRoom("Kitchen", "plastic", 14);
            h.CreateRoom("Bedroom 1", "plastic", 12);
            h.CalculateHouseArea();
            _houses.Add(h);
        }
        /// <summary>
        /// Metod som listar alla hus som finns till uthyrning
        /// </summary>
        public void ShowAllHouses()
        {
            foreach (var item in _houses)
            {
                Console.WriteLine("Område: {0}", item.Neighbourhood);
                Console.WriteLine("Pris: {0}", item.RentalPrice);
                Console.WriteLine("Address: {0}", item.Address);
                Console.WriteLine("Area: {0}", item.HouseArea);
                Console.WriteLine("-------------------------------");
            }
        }

        public void DisplayHouseDetails(int houseindex)
        {
            if (houseindex >= 0 && houseindex < _houses.Count)
            {
                House h = _houses[houseindex];
                h.ShowAllRooms();
            }
            else
            {
                Console.WriteLine("Invalid house index");
            }
        }
    }
}
