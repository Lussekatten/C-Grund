﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_20
{

    class Room
    {
        public Room(string name, string floor, double area)
        {
            Name = name;
            Area = area;
            FloorType = floor;
        }

        public string Name { get; set; }
        public string FloorType { get; set; }
        public double Area { get; set; }
    }
}
