﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_20
{
    class Program
    {
        static void Main(string[] args)
        {
            //The application mananger creates 2 houses as asoon as the object am is created, through the constructor call 
            ApplicationManager am = new ApplicationManager();
            am.ShowAllHouses();
            Console.WriteLine();
            am.DisplayHouseDetails(0);

            Console.ReadLine();
        }
    }
}
