﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_20
{
    class House
    {
        public House(int id, string neighbourhood, int rentalPrice, string address)
        {
            Id = id;
            Neighbourhood = neighbourhood;
            RentalPrice = rentalPrice;
            Address = address;
        }

        public int Id { get; set; } //Ett unikt identifieringsnummer. Används ofta i databaser som primär nyckel
        public int RentalPrice { get; set; } //Hyrespriset per månad
        public string Neighbourhood { get; set; } //Området
        public string Address { get; set; } //Postadressen
        public double HouseArea { get; set; } //Den totala bostadsytan (summan av alla ytor för de registrerade rummen)
        public bool Furniture { get; set; }  // Om sant så är huset/lägenheten möblerad

        private List<Room> _rooms = new List<Room>(); //lista som lagrar våra hus/lägenheter

        /// <summary>
        /// Metod som skapar ett rum-objekt och lägger den i listan över alla befintliga rum
        /// </summary>
        /// <param name="name">Namnet på rummet</param>
        /// <param name="type">Parkett typen</param>
        /// <param name="area">Ytan</param>
        public void CreateRoom(string name, string type, double area)
        {
            //Creates a room and adds it to the list of rooms
            Room r = new Room(name,type,area);
            _rooms.Add(r);
        }

        /// <summary>
        /// Metod som listar alla rum som finns i ett visst hus/lägenhet
        /// </summary>
        public void ShowAllRooms()
        {
            foreach (var item in _rooms)
            {
                Console.WriteLine("Room: {0}",item.Name);
                Console.WriteLine("Floor: {0}", item.FloorType);
                Console.WriteLine("Area: {0}", item.Area);
                Console.WriteLine("----------------------------");
            }
        }
        public void CalculateHouseArea()
        {
            foreach (var item in _rooms)
            {
                HouseArea += item.Area;
            }
        }

    }
}
