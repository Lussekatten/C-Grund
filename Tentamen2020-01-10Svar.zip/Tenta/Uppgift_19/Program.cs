﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_19
{
    class Program
    {
        static void Main(string[] args)
        {
            //Svar: Enligt Wikipedia så är en algoritm ...en ändlig uppsättning (mängd) otvetydiga instruktioner som efter exekvering löser ett problem.
            //Algoritmer löser alltså ett visst problem.
        }
    }
}
