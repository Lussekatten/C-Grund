﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ange vilket/ vika syntaxfel du hittar i nedanstående kod?

            double interest = 1.06;
            double _mySavings = 3000;
            increase = _mySavings * interest; // increase is a variable that must be declared with a data type 
            int 1answer; // a variable name can not start with a digit 

            Console.WriteLine("myOwnMoney"); // This is actually ok from a syntactic point of view, but the result from the console might come as a surprise.
            Console.Read();
        }
    }
}
