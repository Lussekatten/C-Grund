﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uppgift_10
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vad skrivs ut från följande kod?

            int m = 2;
            while (m < 10)
            {
                if (m > 4 && m < 7)
                {
                    m++;
                    continue;
                }
                if (m > 8)
                {
                    break;
                }
                Console.Write("{0}, ", m);
                m++;
            }
            Console.Read();
            //Svar: 2, 3, 4, 7, 8,
        }
    }
}
