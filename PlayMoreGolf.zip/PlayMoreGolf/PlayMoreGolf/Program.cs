﻿using System;

namespace PlayMoreGolf
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationManager am = new ApplicationManager();
            //am.SimulateStrike(45, 56);
            //am.SimulateStrike(45, 32);
            //am.DisplayStrikeStats();
            int angle;
            int velocity;
            while (am.StrikesSoFar < 10)
            {
                Console.Write("Enter angle: ");
                angle = int.Parse(Console.ReadLine());
                Console.Write("Enter velocity: ");
                velocity = int.Parse(Console.ReadLine());
                am.SimulateStrike(angle, velocity);
            }
            //Console.WriteLine("Hello World!");

            Console.Read();
        }
    }
}
