﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayMoreGolf
{
    class Swing
    {
        public int Angle { get; set; }
        public int Velocity { get; set; }
        public double DistanceTravelled { get; set; }
    }
}
