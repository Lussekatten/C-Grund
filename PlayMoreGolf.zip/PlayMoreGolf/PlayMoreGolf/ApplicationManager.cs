﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayMoreGolf
{
    class ApplicationManager
    {
        public ApplicationManager()
        {
            MaxStrikesAllowed = 10;
            TotalDistanceTravelled = 0;
            CourseLength = rnd.Next(580, 701);
            Swings = new List<Swing>();
        }

        private double _GRAVITY = 9.8;
        public int CourseLength { get; set; }
        public double TotalDistanceTravelled { get; set; }
        public int MaxStrikesAllowed { get; set; }

        public double DistanceToCup { get; set; }
        public int StrikesSoFar { get; set; }

        public List<Swing> Swings { get; set; }

        private Random rnd = new Random(DateTime.Now.Millisecond);

        private Swing  _lastStrike = null;

        public void SimulateStrike(int angle, int velocity)
        {
            //Caps the velocity to 58 m/s sure if it is a realistic number but anyway
            if (velocity > 58)
            {
                velocity = 58;
            }
            double angleInRadians = (Math.PI / 180) * angle;
            double distance = Math.Pow(velocity, 2) / _GRAVITY * Math.Sin(2 * angleInRadians);

            TotalDistanceTravelled += distance;
            DistanceToCup = (double)CourseLength - TotalDistanceTravelled;

            //Create the strike object to put in the list of strikes
            Swing strike = new Swing();
            strike.Angle = angle;
            strike.Velocity = velocity;
            strike.DistanceTravelled = distance;

            //Save the information about the last strike here to display to the user (if needed)
            _lastStrike = strike;

            //Add it to the list
            Swings.Add(strike);
            StrikesSoFar++;
        }
        public void DisplayStrikeStats()
        {
            foreach (var item in Swings)
            {
                Console.WriteLine("Strike {0}", Swings.IndexOf(item) + 1);
                Console.WriteLine("Angle {0}", item.Angle);
                Console.WriteLine("Velocity {0}", item.Velocity);
                Console.WriteLine("Distance {0:0.00} m", item.DistanceTravelled);
                Console.WriteLine("---------------------------------------");
            }
        }
    }
}
